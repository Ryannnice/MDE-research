    
import struct
import ctypes
from typing_extensions import (
    Literal,
)
import math

PI = math.pi
DEG2RAD = math.pi / 180.0
RAD2DEG = 180.0 / math.pi

class NumericCodec():
    '''
    数字编解码
    '''
    @staticmethod
    def ConvertToNegative_8bit(value: int, signed:bool=True) -> int:
        '''
        Convert the input integer to an 8-bit integer.
        input value range:[0,255]
        If signed is True, it will be converted to a 32-bit signed integer. [-128, 127]
        If signed is False, it will be converted to a 32-bit unsigned integer. [0, 255]
        '''
        '''
        将输入的整数转换为8位整数。
        输入 value 范围:[0,255]
        如果 signed 为 True,则转换为8位有符号整数。[-128, 127]
        如果 signed 为 False,则转换为8位无符号整数。[0, 255]
        '''
        # 范围检查
        if not (0 <= value <= 255):
            raise OverflowError("Error ConvertToNegative_8bit:  Input value exceeds the range [0, 255].")
        # 转换成 8 位无符号整数
        value &= 0xFF  # 将 value 转换成 8 位无符号整数
        if signed:
            if value & 0x80:  # 检查符号位
                value -= 0x100  # 如果符号位为 1，表示负数，需要减去 2^8
        return value

    @staticmethod
    def ConvertToNegative_int8_t(value: int) -> int:
        '''
        Convert the input integer to an 8-bit signed integer.
        input value range:[0,255]
        return Range: [-128, 127]
        '''
        '''
        将输入的整数转换为8位有符号整数。
        输入 value 范围:[0,255]
        return范围: [-128, 127]
        '''
        # 范围检查
        if not (0 <= value <= 255):
            raise OverflowError("Error ConvertToNegative_int8_t: Input value exceeds the range [0, 255].")
        # 转换成 8 位无符号整数
        value &= 0xFF  # 将 value 转换成 8 位无符号整数
        if value & 0x80:  # 检查符号位
            value -= 0x100  # 如果符号位为 1，表示负数，需要减去 2^8
        return value

    @staticmethod
    def ConvertToNegative_uint8_t(value: int) -> int:
        '''
        Convert the input integer to an 8-bit unsigned integer.
        input value range:[0,255]
        return Range: [0, 255]
        '''
        '''
        将输入的整数转换为8位无符号整数。
        输入 value 范围:[0,255]
        return 范围: [0, 255]
        '''
        # 范围检查
        if not (0 <= value <= 255):
            raise OverflowError("Error ConvertToNegative_uint8_t: Input value exceeds the range [0, 255].")
        # 转换成 8 位无符号整数
        value &= 0xFF  # 将 value 转换成 8 位无符号整数
        return value

    @staticmethod
    def ConvertToNegative_16bit(value: int, signed:bool=True) -> int:
        '''
        Convert the input integer to a 16-bit integer.
        input value range:[0,65535]
        If signed is True, it will be converted to a 16-bit signed integer. Range: [-32768, 32767]
        If signed is False, it will be converted to a 16-bit unsigned integer. Range: [0, 65535]
        '''
        '''
        将输入的整数转换为16位整数。
        输入 value 范围:[0,65535]
        如果 signed 为 True,则转换为16位有符号整数。[-32768, 32767]
        如果 signed 为 False,则转换为16位无符号整数。[0, 65535]
        '''
        # 范围检查
        if not (0 <= value <= 65535):
            raise OverflowError("Error ConvertToNegative_16bit: Input value exceeds the range [0, 65535].")
        # 转换成 16 位无符号整数
        value &= 0xFFFF  # 将 value 转换成 16 位无符号整数
        if signed:
            if value & 0x8000:  # 检查符号位
                value -= 0x10000  # 如果符号位为 1，表示负数，需要减去 2^16
        return value
    
    @staticmethod
    def ConvertToNegative_int16_t(value: int) -> int:
        '''
        Convert the input integer to a 16-bit signed integer.
        input value range:[0,65535]
        return Range: [-32768, 32767]
        '''
        '''
        将输入的整数转换为16位有符号整数。
        输入 value 范围:[0,65535]
        return 范围: [-32768, 32767]
        '''
        # 范围检查
        if not (0 <= value <= 65535):
            raise OverflowError("Error ConvertToNegative_int16_t: Input value exceeds the range [0, 65535].")
        # 转换成 8 位无符号整数
        value &= 0xFFFF  # 将 value 转换成 8 位无符号整数
        if value & 0x8000:  # 检查符号位
            value -= 0x10000  # 如果符号位为 1，表示负数，需要减去 2^8
        return value

    @staticmethod
    def ConvertToNegative_uint16_t(value: int) -> int:
        '''
        Convert the input integer to a 16-bit unsigned integer.
        input value range:[0,65535]
        return Range: [0, 65535]
        '''
        '''
        将输入的整数转换为16位无符号整数。
        输入 value 范围:[0,65535]
        return 范围: [0, 65535]
        '''
        # 范围检查
        if not (0 <= value <= 65535):
            raise OverflowError("Error ConvertToNegative_uint16_t: Input value exceeds the range [0, 65535].")
        # 转换成 8 位无符号整数
        value &= 0xFFFF  # 将 value 转换成 8 位无符号整数
        return value

    @staticmethod
    def ConvertToNegative_32bit(value:int, signed:bool=True):
        '''
        Convert the input integer to a 32-bit integer.
        input value range:[0,4294967295]
        If signed is True, it will be converted to a 32-bit signed integer.
        If signed is False, it will be converted to a 32-bit unsigned integer.
        '''
        '''
        将输入的整数转换为32位整数。
        输入 value 范围:[0,4294967295]
        如果 signed 为 True,则转换为32位有符号整数。
        如果 signed 为 False,则转换为32位无符号整数。
        '''
        # 范围检查
        if not (0 <= value <= 4294967295):
            raise OverflowError("Error ConvertToNegative_32bit: Input value exceeds the range [0, 4294967295].")
        # 转换成 32 位无符号整数
        value &= 0xFFFFFFFF  # 将 value 转换成 32 位无符号整数
        if signed:
            if value & 0x80000000:  # 检查符号位
                value -= 0x100000000  # 如果符号位为 1，表示负数，需要减去 2^32
        return value
    
    @staticmethod
    def ConvertToNegative_int32_t(value: int) -> int:
        '''
        Convert the input integer to a 32-bit signed integer.
        input value range:[0,4294967295]
        return Range: [-2147483648, 2147483647].
        '''
        '''
        将输入的整数转换为32位有符号整数。
        输入 value 范围:[0,4294967295]
        return范围: [-2147483648, 2147483647]
        '''
        # 范围检查
        if not (0 <= value <= 4294967295):
            raise OverflowError("Error ConvertToNegative_int32_t: Input value exceeds the range [0, 4294967295].")
        # 转换成 8 位无符号整数
        value &= 0xFFFFFFFF  # 将 value 转换成 8 位无符号整数
        if value & 0x80000000:  # 检查符号位
            value -= 0x100000000  # 如果符号位为 1，表示负数，需要减去 2^8
        return value

    @staticmethod
    def ConvertToNegative_uint32_t(value: int) -> int:
        '''
        Convert the input integer to a 32-bit unsigned integer.
        input value range:[0,4294967295]
        return Range: [0, 4294967295].
        '''
        '''
        将输入的整数转换为32位无符号整数。
        输入 value 范围:[0,4294967295]
        return范围: [0, 4294967295]
        '''
        # 范围检查
        if not (0 <= value <= 4294967295):
            raise OverflowError("Error ConvertToNegative_uint32_t: Input value exceeds the range [0, 4294967295].")
        # 转换成 8 位无符号整数
        value &= 0xFFFFFFFF  # 将 value 转换成 8 位无符号整数
        return value

    @staticmethod
    def ConvertToList_8bit(value: int, signed: bool = True):
        '''
        Convert the input integer into an 8-bit integer list.
        The signed parameter determines whether it is treated as a signed integer.
        A warning will be given if the value exceeds the allowed range.
        '''
        '''
        将输入的整数转换为8位整数列表。
        根据signed参数判断是否将其视为带符号整数。
        超出范围时给出提示。
        '''
        if signed:
            if not -128 <= value <= 127:
                raise OverflowError(f"The input value {value} exceeds the range of an 8-bit signed integer [-128, 127].")
            value = ctypes.c_int8(value).value
            return list(struct.unpack("B", struct.pack(">b", value)))
        else:
            if not 0 <= value <= 255:
                raise OverflowError(f"The input value {value} exceeds the range of an 8-bit unsigned integer [0, 255].")
            return list(struct.unpack("B", struct.pack(">B", value)))
    
    @staticmethod
    def ConvertToList_int8_t(value: int):
        if not -128 <= value <= 127:
            raise OverflowError(f"输入的值 {value} 超出了8位有符号整数的范围 [-128, 127].")
        if value < 0:
            value = (value + 0x100) & 0xFF  # 转换为8位表示
        else:
            value &= 0xFF
        return [value]
    
    @staticmethod
    def ConvertToList_uint8_t(value: int):
        if not 0 <= value <= 255:
            raise OverflowError(f"输入的值 {value} 超出了8位无符号整数的范围 [0, 255].")
        value &= 0xFF
        return [value]

    @staticmethod
    def ConvertToList_16bit(value: int, signed: bool = True):
        '''
        Convert the input integer into a 16-bit integer list.
        The signed parameter determines whether it is treated as a signed integer.
        A warning will be given if the value exceeds the allowed range.
        '''
        '''
        将输入的整数转换为16位整数列表。
        根据signed参数判断是否将其视为带符号整数。
        超出范围时给出提示。
        '''
        if signed:
            if not -32768 <= value <= 32767:
                raise OverflowError(f"The input value {value} exceeds the range of a 16-bit signed integer [-32768, 32767].")
            value = ctypes.c_int16(value).value
            return list(struct.unpack("BB", struct.pack(">h", value)))
        else:
            if not 0 <= value <= 65535:
                raise OverflowError(f"The input value {value} exceeds the range of a 16-bit unsigned integer [0, 65535].")
            return list(struct.unpack("BB", struct.pack(">H", value)))

    @staticmethod
    def ConvertToList_int16_t(value: int):
        if not -32768 <= value <= 32767:
            raise OverflowError(f"输入的值 {value} 超出了16位有符号整数的范围 [-32768, 32767].")
        if value < 0:
            value = (value + 0x10000) & 0xFFFF  # 转换为16位表示
        else:
            value &= 0xFFFF
        # 将结果拆分为两个uint8值
        high_byte = (value >> 8) & 0xFF
        low_byte = value & 0xFF
        return [high_byte, low_byte]
    
    @staticmethod
    def ConvertToList_uint16_t(value: int):
        if not 0 <= value <= 65535:
            raise OverflowError(f"输入的值 {value} 超出了16位无符号整数的范围 [0, 65535].")
        value &= 0xFFFF
        # 将结果拆分为两个uint8值
        high_byte = (value >> 8) & 0xFF
        low_byte = value & 0xFF
        return [high_byte, low_byte]

    @staticmethod
    def ConvertToList_32bit(value: int, signed: bool = True):
        '''
        Convert the input integer into a 32-bit integer list.
        The signed parameter determines whether it is treated as a signed integer.
        A warning will be given if the value exceeds the allowed range.
        '''
        '''
        将输入的整数转换为32位整数列表。
        根据signed参数判断是否将其视为带符号整数。
        超出范围时给出提示。
        '''
        if signed:
            if not -2147483648 <= value <= 2147483647:
                raise OverflowError(f"The input value {value} exceeds the range of a 32-bit signed integer [-2147483648, 2147483647].")
            value = ctypes.c_int32(value).value
            return list(struct.unpack("BBBB", struct.pack(">i", value)))
        else:
            if not 0 <= value <= 4294967295:
                raise OverflowError(f"The input value {value} exceeds the range of a 32-bit unsigned integer [0, 4294967295].")
            return list(struct.unpack("BBBB", struct.pack(">I", value)))

    @staticmethod
    def ConvertToList_int32_t(value: int):
        if not -2147483648 <= value <= 2147483647:
            raise OverflowError(f"输入的值 {value} 超出了32位有符号整数的范围 [-2147483648, 2147483647].")
        if value < 0:
            value = (value + 0x100000000) & 0xFFFFFFFF  # 转换为32位表示
        else:
            value &= 0xFFFFFFFF
        # 将结果拆分为四个uint8值
        byte_3 = (value >> 24) & 0xFF
        byte_2 = (value >> 16) & 0xFF
        byte_1 = (value >> 8) & 0xFF
        byte_0 = value & 0xFF
        return [byte_3, byte_2, byte_1, byte_0]
    
    @staticmethod
    def ConvertToList_uint32_t(value: int):
        if not 0 <= value <= 4294967295:
            raise OverflowError(f"输入的值 {value} 超出了32位无符号整数的范围 [0, 4294967295].")
        value &= 0xFFFFFFFF
        # 将结果拆分为四个uint8值
        byte_3 = (value >> 24) & 0xFF
        byte_2 = (value >> 16) & 0xFF
        byte_1 = (value >> 8) & 0xFF
        byte_0 = value & 0xFF
        return [byte_3, byte_2, byte_1, byte_0]

    @staticmethod
    def FloatToUint(x_float:float, x_min:float, x_max:float, bits:int):
        '''
        Convert floating point number to unsigned integer
        Used in MIT mode pass-through control for individual joint motor driver mode
        '''
        '''
        浮点数转换为无符号整数
        用在mit模式透传控制单独关节电机驱动器模式
        '''
        span:float = x_max - x_min
        offset:float = x_min
        return int((x_float - offset) * (float((1<<bits)-1))/span)
    
    @staticmethod
    def ConvertBytesToInt(bytes:bytearray, first_index:int, second_index:int, byteorder:Literal["little", "big"]='big'):
        '''
        将字节串转换为int类型,默认为大端对齐
        '''
        '''
        Convert a byte string to an int type, with big-endian byte order by default.
        '''
        return int.from_bytes(bytes[first_index:second_index], byteorder=byteorder)

    @staticmethod
    def from_bytes_to_float(byte_data: bytearray, byteorder: Literal['big', 'little'] = 'little') -> float:
        """
        将长度为4的字节数组转换为浮点数
        :param byte_data: 字节数组（或 bytes 对象）
        :param byteorder: 'big' 或 'little'
        :return: 对应的浮点数
        """
        if len(byte_data) < 4:
            raise ValueError("Byte array must contain at least 4 bytes")
        fmt = '>' if byteorder == 'big' else '<'
        return struct.unpack(fmt + 'f', byte_data[:4])[0]
    
    @staticmethod
    def from_float_to_bytes(float_data: float, byteorder: Literal['big', 'little'] = 'little') -> bytearray:
        """
        将浮点数转换为长度为4的字节数组
        :param float_data: 浮点数
        :param byteorder: 'big' 或 'little'
        :return: 对应的字节数组（bytearray）
        """
        fmt = '>' if byteorder == 'big' else '<'
        return bytearray(struct.pack(fmt + 'f', float_data))
    
    @staticmethod
    def from_bytes_to_double(byte_data: bytearray, byteorder: Literal['big', 'little'] = 'little') -> float:
        """
        将长度为8的字节数组转换为双精度浮点数
        :param byte_data: 字节数组（或 bytes 对象）
        :param byteorder: 'big' 或 'little'
        :return: 对应的双精度浮点数
        """
        if len(byte_data) < 8:
            raise ValueError("Byte array must contain at least 8 bytes")
        fmt = '>' if byteorder == 'big' else '<'
        return struct.unpack(fmt + 'd', byte_data[:8])[0]

    @staticmethod
    def from_double_to_bytes(double_data: float, byteorder: Literal['big', 'little'] = 'little') -> bytearray:
        """
        将双精度浮点数转换为长度为8的字节数组
        :param double_data: 双精度浮点数
        :param byteorder: 'big' 或 'little'
        :return: 对应的字节数组（bytearray）
        """
        fmt = '>' if byteorder == 'big' else '<'
        return bytearray(struct.pack(fmt + 'd', double_data))
