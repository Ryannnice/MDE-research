#!/usr/bin/env python3
"""Server-side client for the loopback PIPER bridge."""

from __future__ import annotations

import argparse
import json
import math
import os
import time
import uuid
from pathlib import Path
from typing import Any, Dict, Optional
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


TERMINAL_STATES = {"completed", "stopped", "fault", "timed_out", "error"}


class ClientError(RuntimeError):
    pass


class PiperClient:
    def __init__(self, base_url: str, token: str, timeout_s: float = 5.0):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout_s = timeout_s

    def request(
        self,
        method: str,
        path: str,
        body: Optional[Dict[str, Any]] = None,
        authenticated: bool = True,
    ) -> Dict[str, Any]:
        data = None
        headers = {"Accept": "application/json"}
        if authenticated:
            headers["Authorization"] = f"Bearer {self.token}"
        if body is not None:
            data = json.dumps(body, allow_nan=False).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = Request(
            self.base_url + path,
            data=data,
            headers=headers,
            method=method,
        )
        try:
            with urlopen(request, timeout=self.timeout_s) as response:
                payload = json.loads(response.read().decode("utf-8"))
        except HTTPError as exc:
            try:
                payload = json.loads(exc.read().decode("utf-8"))
                detail = payload.get("error", {})
                message = f"{detail.get('code', exc.code)}: {detail.get('message', exc.reason)}"
            except Exception:
                message = f"HTTP {exc.code}: {exc.reason}"
            raise ClientError(message) from exc
        except (URLError, TimeoutError, json.JSONDecodeError) as exc:
            raise ClientError(str(exc)) from exc
        if not payload.get("ok"):
            raise ClientError(str(payload))
        return payload

    def health(self):
        return self.request("GET", "/v1/health", authenticated=False)

    def state(self):
        return self.request("GET", "/v1/state")["state"]

    def prepare(self):
        return self.request("POST", "/v1/prepare", {})

    def enable(self):
        return self.request("POST", "/v1/enable", {})

    def stop(self):
        return self.request("POST", "/v1/stop", {})

    def move_joints(self, target_rad, expected_current_rad, speed_percent: int):
        command_id = uuid.uuid4().hex
        payload = {
            "command_id": command_id,
            "target_rad": target_rad,
            "expected_current_rad": expected_current_rad,
            "speed_percent": speed_percent,
        }
        return self.request("POST", "/v1/move-joints", payload)["command"]

    def command(self, command_id: str):
        return self.request("GET", f"/v1/commands/{command_id}")["command"]

    def wait_command(self, command_id: str, timeout_s: float = 15.0):
        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            command = self.command(command_id)
            if command["status"] in TERMINAL_STATES:
                return command
            time.sleep(0.1)
        raise ClientError(f"client timed out waiting for command {command_id}")


def _default_token_file() -> Path:
    return Path(__file__).resolve().with_name("session-token.txt")


def _read_token(path: Optional[str]) -> str:
    token = os.environ.get("PIPER_BRIDGE_TOKEN", "")
    token_path = Path(path).expanduser() if path else _default_token_file()
    if not token and token_path.is_file():
        token = token_path.read_text(encoding="utf-8").strip()
    if len(token) < 32:
        raise SystemExit(
            "No valid token. Set PIPER_BRIDGE_TOKEN or create session-token.txt "
            "beside this script."
        )
    return token


def _print(payload: Any) -> None:
    print(json.dumps(payload, ensure_ascii=False, indent=2, default=str))


def _joint_values(state: Dict[str, Any]):
    values = state.get("arm", {}).get("joint_angles_rad")
    if not isinstance(values, list) or len(values) != 6:
        raise ClientError("bridge did not return six joint angles")
    return [float(value) for value in values]


def _parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--url",
        default=os.environ.get("PIPER_BRIDGE_URL", "http://127.0.0.1:8765"),
    )
    parser.add_argument("--token-file", default=None)
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("health")
    subparsers.add_parser("state")
    subparsers.add_parser("prepare")
    subparsers.add_parser("enable")
    subparsers.add_parser("stop")

    relative = subparsers.add_parser("move-relative")
    relative.add_argument("--joint", type=int, choices=range(1, 7), required=True)
    relative.add_argument("--degrees", type=float, required=True)
    relative.add_argument("--speed-percent", type=int, default=5)
    relative.add_argument("--execute", action="store_true")

    absolute = subparsers.add_parser("move-absolute")
    absolute.add_argument("--target-rad", type=float, nargs=6, required=True)
    absolute.add_argument("--speed-percent", type=int, default=5)
    absolute.add_argument("--execute", action="store_true")

    command_status = subparsers.add_parser("command-status")
    command_status.add_argument("command_id")
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    token = _read_token(args.token_file)
    client = PiperClient(args.url, token)

    if args.command == "health":
        _print(client.health())
        return 0
    if args.command == "state":
        _print(client.state())
        return 0
    if args.command == "prepare":
        _print(client.prepare())
        return 0
    if args.command == "enable":
        _print(client.enable())
        return 0
    if args.command == "stop":
        _print(client.stop())
        return 0
    if args.command == "command-status":
        _print(client.command(args.command_id))
        return 0

    state = client.state()
    current = _joint_values(state)
    if args.command == "move-relative":
        if not math.isfinite(args.degrees):
            raise ClientError("degrees must be finite")
        target = list(current)
        target[args.joint - 1] += math.radians(args.degrees)
    else:
        target = list(args.target_rad)

    preview = {
        "current_rad": current,
        "target_rad": target,
        "delta_deg": [round(math.degrees(b - a), 6) for a, b in zip(current, target)],
        "speed_percent": args.speed_percent,
    }
    _print(preview)
    if not args.execute:
        print("Preview only. Add --execute after the on-site operator approves this target.")
        return 2

    command = client.move_joints(target, current, args.speed_percent)
    _print(command)
    result = client.wait_command(command["command_id"])
    _print(result)
    return 0 if result["status"] == "completed" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except ClientError as exc:
        raise SystemExit(f"PIPER client error: {exc}") from exc
