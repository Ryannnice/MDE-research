# PIPER 安全远程桥

这个目录把远程推理与本地 CAN 控制隔开：服务器只提交有限关节目标，Windows 电脑负责实时反馈、关节限位、现场许可和电子急停。

## 不可绕过的安全规则

- 第一次启动只能使用 `start_observe.ps1`；观察模式没有使能或运动代码路径。
- 实机运动前，现场人员必须清空整个工作空间，并能立即操作实体急停或安全断电。
- 控制模式仍默认拒绝动作。现场人员必须在桥接窗口输入 `ARM WORKSPACE CLEAR`，许可五分钟。
- 运动前必须单独执行 `prepare`；它只选择 5% 速度的 CAN/MOVE J 模式并等待状态反馈，不发送关节目标。
- 每条命令最多改变任一关节 3°，速度最多 5%，并且必须基于刚读取的关节状态。
- 运动超时或反馈故障会发送 SDK 的阻尼电子急停。电子急停后不自动复位。
- 退出空闲桥接程序不会自动失能，因为突然失能可能让机械臂下落。退出运动中的桥接程序会尝试电子急停。
- 当前阶段不开放 `reset`、远程失能、MIT 模式、笛卡尔运动或原始 CAN 帧。

## Windows 安装

要求：Windows 10/11、64 位 Python 3.11/3.12、随臂官方 USB-CAN。CAN 波特率由驱动固定为 1 Mbps。

在普通 PowerShell 中进入本目录：

```powershell
powershell -ExecutionPolicy Bypass -File .\setup_windows.ps1
```

脚本会建立 `.venv`，并从本目录 `vendor/` 的离线源码包安装固定提交的官方组件，不依赖 Windows 访问 GitHub：

- `agilexrobotics/pyAgxArm@799b8412fbe8b9156bc9892d3dbeb2df7e98be71`
- `agilexrobotics/python-can-agx-cando@b222c4027ad4f6599f7634c72c67184619177972`

如果目录中没有 `session-token.txt`，安装脚本会生成一个。Windows 和服务器必须使用同一个文件。

## 第一次只读连接

普通 PIPER、固件不明时先运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\start_observe.ps1
```

其他型号使用 `-Model piper_h`、`piper_l` 或 `piper_x`。固件档位：

| 主控固件 | 参数 |
|---|---|
| `<= S-V1.8-2` | `default` |
| `S-V1.8-3` 至 `S-V1.8-7` | `v183` |
| `S-V1.8-8` | `v188` |
| `>= S-V1.8-9` | `v189` |

只读成功时窗口会打印 `connected: true`、六个 `joint_angles_rad`、`arm_status: NORMAL`、`err_code: 0` 和固件信息，然后显示：

```text
PIPER bridge ready on http://127.0.0.1:<LOCAL_PORT> (observe mode)
```

## 反向 SSH 隧道

保持桥接窗口运行，另开一个 Windows PowerShell。把 `<学校服务器>` 换成 VS Code Remote-SSH 使用的主机别名：

```powershell
ssh -NT `
  -R 127.0.0.1:8765:127.0.0.1:<LOCAL_PORT> `
  -o ExitOnForwardFailure=yes `
  -o ServerAliveInterval=5 `
  -o ServerAliveCountMax=3 `
  <学校服务器>
```

服务器端随后只能通过自己的 `127.0.0.1:8765` 访问本地桥；不需要开放 Windows 防火墙端口或路由器端口。

## 服务器核验

```bash
python3 piper_client.py health
python3 piper_client.py state
```

模拟测试：

```bash
python3 -m unittest discover -s tests -t . -v
```

## 控制阶段

只在观察数据核验完成后关闭观察桥，运行：

```powershell
powershell -ExecutionPolicy Bypass -File .\start_control.ps1 -Firmware v189
```

桥接器重启后通常会得到新的 `<LOCAL_PORT>`；同时重启 SSH 隧道，并把转发目标改成这个新端口。

现场清场后，在同一窗口输入：

```text
ARM WORKSPACE CLEAR
```

服务器先执行无目标的控制模式准备，确认 `ctrl_mode` 变为 `CAN_CTRL`，然后使能并预览动作：

```bash
python3 piper_client.py prepare
python3 piper_client.py enable
python3 piper_client.py state
python3 piper_client.py move-relative --joint 6 --degrees 1
```

预览不会运动；只有显式增加 `--execute` 才提交。现场或服务器均可发送电子急停，现场窗口直接输入 `STOP`，服务器运行：

```bash
python3 piper_client.py stop
```

若当前反馈略微超出官方关节限位，普通相对动作会被拒绝。必须先规划一个不超过 3°、目标回到限位内的显式绝对动作；桥不会关闭 SDK 限位或静默保留越限目标。

## 官方依据

- [pyAgxArm Windows 与 PIPER 支持](https://github.com/agilexrobotics/pyAgxArm)
- [Windows `agx_cando` 插件](https://github.com/agilexrobotics/python-can-agx-cando)
- [CAN 模块说明](https://github.com/agilexrobotics/pyAgxArm/blob/master/docs/can_user.md)
